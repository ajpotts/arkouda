from numpy.rec import format_parser

__all__ = ["format_parser"]
