from numpy import bool_

__all__ = ["bool_"]
