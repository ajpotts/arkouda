from numpy import integer

__all__ = ["integer"]
