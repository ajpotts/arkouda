from numpy.lib.npyio import DataSource

__all__ = ["DataSource"]
