# flake8: noqa
from numpy.lib import add_docstring, add_newdoc

__all__ = [
    "add_docstring",
    "add_newdoc",
    "emath",
]
