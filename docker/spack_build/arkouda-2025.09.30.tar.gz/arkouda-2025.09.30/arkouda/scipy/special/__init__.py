from ._math import xlogy

__all__ = [
    "xlogy",
]
