# mypy: ignore-errors
from scipy.stats import chi2  # type: ignore[import-untyped]

__all__ = ["chi2"]
