# flake8: noqa

from arkouda.numpy.segarray import SegArray
