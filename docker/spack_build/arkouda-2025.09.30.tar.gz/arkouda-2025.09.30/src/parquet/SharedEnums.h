#ifndef SHARED_ENUMS_H
#define SHARED_ENUMS_H

#include "../ParquetSharedEnums.chpl"

#endif // SHARED_ENUMS_H
