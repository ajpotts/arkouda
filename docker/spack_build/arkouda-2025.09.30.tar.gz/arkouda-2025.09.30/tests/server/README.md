# Arkouda Chapel Unit Tests

## Executing the Arkouda Chapel unit tests

All Chapel unit tests are executed via the following make goal:

```
make test-chapel
```
