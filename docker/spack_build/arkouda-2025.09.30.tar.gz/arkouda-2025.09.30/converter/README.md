# Python converter from CSV to HDF5

  * example of conversion of the open LANL netflow data from CSV to HDF5
  * the script `cmd.sh` contains an example of usage to download and convert data for use with arkouda

