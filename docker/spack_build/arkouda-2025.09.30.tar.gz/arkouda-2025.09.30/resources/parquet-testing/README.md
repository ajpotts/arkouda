# Files from apache/parquet-testing

The files in this directory have been copied from github.com/apache/parquet-testing and are under the Apache 2.0 license included in this directory. They are unmodified from their original state and used solely for testing parquet functionality in Arkouda.