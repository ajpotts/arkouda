.. _dev-label:

Developer Documentation
=========================

Here you will find documentation useful for development in Arkouda.

.. toctree::
    :maxdepth: 1

    BUILDING_CHAPEL
    TIPS
    USER_BUGS
    MEMORY
    GASNET
    RELEASE_PROCESS
    BENCHMARK
    ADDING_FEATURES
