.. _usage-label:

#############
Usage Guide
#############

.. toctree::

   usage/startup
   usage/pdarray
   usage/creation
   usage/arithmetic
   usage/indexing
   usage/histogram
   usage/argsort
   usage/setops
   usage/groupby
   usage/strings
   usage/categorical
   usage/random
   usage/segarray
   usage/arrayview
