.. _sorting-label:

************
Sorting
************

.. autofunction:: arkouda.argsort

.. autofunction:: arkouda.coargsort
